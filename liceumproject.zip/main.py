import datetime
import sys

from PyQt5.QtCore import pyqtSignal
from PyQt5.QtGui import QFont

import icons
import sqlite3
import PyQt5
from PyQt5 import uic, QtCore, QtWidgets, Qt
from PyQt5.QtWidgets import QApplication, QMainWindow, QInputDialog, QTableWidgetItem, QCheckBox, QLabel

# помогает праветьному отображению дизайна
if hasattr(QtCore.Qt, 'AA_EnableHighDpiScaling'):
    PyQt5.QtWidgets.QApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling, True)

if hasattr(QtCore.Qt, 'AA_UseHighDpiPixmaps'):
    PyQt5.QtWidgets.QApplication.setAttribute(QtCore.Qt.AA_UseHighDpiPixmaps, True)


# создаю свой QCheckbox с реакцией на нажатие правой кнопкой мыши
class MyCheckBox(Qt.QCheckBox):
    selecteds = pyqtSignal()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def mousePressEvent(self, event):
        button = event.button()
        if button == Qt.Qt.RightButton:
            self.selecteds.emit()
        else:
            if self.isChecked():
                self.setChecked(False)
            else:
                self.setChecked(True)


class MyWidget(QMainWindow):
    def __init__(self):
        super().__init__()
        # подключаю дизайн и бд
        uic.loadUi('project.ui', self)
        self.setWindowTitle('MyPlanner')
        self.connect = sqlite3.connect('tasks.sqlite')
        self.cur = self.connect.cursor()
        # загружаю начальную страницу
        fl = 0
        for i in self.cur.execute('''SELECT title from acttasks WHERE date = ?''', (
                datetime.date.today(),)).fetchall():
            fl = 1
            a = MyCheckBox(i[0], self)
            a.selecteds.connect(self.edittask)
            a.setFont(QFont('MS Shell Dlg 2', 10))
            a.setStyleSheet("MyCheckBox::indicator"
                            "{"
                            "width :15px;"
                            "height :15px;"
                            "}")
            self.verticalLayoutpage1.insertWidget(0, a)
        if not fl:
            self.label_2.setText('No Tasks For Today')
        # обработка сигналов нажатия на кнопки меню
        self.tasks.clicked.connect(self.tasks_b)
        self.calendar.clicked.connect(self.calendar_b)
        self.schedule.clicked.connect(self.schedule_b)
        self.settings.clicked.connect(self.settings_b)
        # обработка сигналов нажатия на кнопки меню в разделе tasks
        self.today.clicked.connect(self.today_b)
        self.lists.clicked.connect(self.lists_b)
        self.completed.clicked.connect(self.completed_b)
        self.deleted.clicked.connect(self.deleted_b)
        # обработка сигнала нажатия на кнопку добавления задачи
        self.addtask.clicked.connect(self.addtask_b)
        # заполнение таблицы расписания
        res = self.cur.execute('SELECT Monday, Tuesday,'
                               ' Wednesday, Thursday,'
                               ' Friday, Saturday FROM timetable').fetchall()
        self.sh = ['8:30 - 9:15', '9:30 - 10:15', '10:35 - 11:20', '11:40 - 12:25',
                   '12:40 - 13:25', '13:45 - 14:30', '14:50 - 15:35', '15:45 - 16:30']
        # Заполнение размеров таблицы
        self.tableWidget.setColumnCount(6)
        self.tableWidget.setRowCount(0)
        # Заполнение таблицы элементами
        for i, row in enumerate(res):
            self.tableWidget.setRowCount(
                self.tableWidget.rowCount() + 1)
            for j, elem in enumerate(row):
                self.tableWidget.setItem(
                    i, j, QTableWidgetItem(str(elem)))
        self.tableWidget.setHorizontalHeaderLabels(['Monday', 'Tuesday', 'Wednesday', 'Thursday',
                                                    'Friday', 'Saturday'])
        # настройка видженов р разделе расписания
        self.teacher.setReadOnly(True)
        self.time.setReadOnly(True)
        self.klass.setReadOnly(True)
        # обработка сигнала нажатия на урок
        self.tableWidget.cellClicked.connect(self.tablef)
        # определение группы по 4 предметам из бд
        ind = self.m_group.findText(self.cur.execute(
            '''SELECT groupp from groups WHERE subj = "Алг./Геом."''').fetchall()[0][0])
        self.m_group.setCurrentIndex(ind)
        ind = self.e_group.findText(self.cur.execute(
            '''SELECT groupp from groups WHERE subj = "Английский язык"''').fetchall()[0][0])
        self.e_group.setCurrentIndex(ind)
        ind = self.i_group.findText(self.cur.execute(
            '''SELECT groupp from groups WHERE subj = "Информатика"''').fetchall()[0][0])
        self.i_group.setCurrentIndex(ind)
        ind = self.c_group.findText(self.cur.execute(
            '''SELECT groupp from groups WHERE subj = "Спецкурс"''').fetchall()[0][0])
        self.c_group.setCurrentIndex(ind)
        # обработка сигналов на изменение группы по предметам
        self.m_group.currentTextChanged.connect(self.groupm)
        self.e_group.currentTextChanged.connect(self.groupe)
        self.i_group.currentTextChanged.connect(self.groupi)
        self.c_group.currentTextChanged.connect(self.groupc)
        # обработка сигнала нажатия на дату календаря
        self.calendarWidget.clicked.connect(self.calendartasks)
        # обработка сигналов нажатия на кнопки завершения задач
        self.savefromc.clicked.connect(lambda x: self.savetoc(
            self.verticalLayoutcalendar, self.dateselected.text()))
        self.savetocompl.clicked.connect(lambda x: self.savetoc(
            self.verticalLayoutpage1, datetime.date.today()))
        self.savetocompl1.clicked.connect(lambda x: self.savetoc(
            self.verticalLayoutpage2, list=self.listsbox.currentText()))
        # настройка виджетов изменения задачи
        self.saveb.setEnabled(False)
        self.delete_2.setEnabled(False)
        self.textEdit.setReadOnly(True)
        self.textEdit_2.setReadOnly(True)
        self.dateEdit.setDate(datetime.date.today())
        lists = self.cur.execute('''SELECT title from lists''').fetchall()
        self.comboBox_2.addItems([i[0] for i in lists])
        # обработка сигнала нажатия на кнопку сохранения изменений и удаления задачи
        self.saveb.clicked.connect(self.saving)
        self.whatediting = ''
        self.delete_2.clicked.connect(self.delb)
        # обработка сигнала изменения выбранного списка задач
        self.listsbox.currentIndexChanged.connect(self.listselection)
        # обработка сигнала и настройка кнопки добавления задачи в список
        self.addtasktl.setEnabled(False)
        self.addtasktl.clicked.connect(self.addtasktl_b)

    def clearLayout(self, layout):
        # очистка списков задач
        while layout.count() > 1:
            child = layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

    def tasks_b(self):
        # реакция на нажатие кнопки меню
        if not self.tasks.isChecked():
            self.tasks.setChecked(True)
        if self.calendar.isChecked():
            self.calendar.setChecked(False)
        if self.schedule.isChecked():
            self.schedule.setChecked(False)
        if self.settings.isChecked():
            self.settings.setChecked(False)
        self.stackedWidget.setCurrentIndex(0)
        self.clearLayout(self.verticalLayoutpage1)
        fl = 0
        for i in self.cur.execute('''SELECT title from acttasks WHERE date = ?''', (
                datetime.date.today(),)).fetchall():
            fl = 1
            a = MyCheckBox(i[0], self)
            a.selecteds.connect(self.edittask)
            a.setFont(QFont('MS Shell Dlg 2', 10))
            a.setStyleSheet("MyCheckBox::indicator"
                            "{"
                            "width :15px;"
                            "height :15px;"
                            "}")
            self.verticalLayoutpage1.insertWidget(0, a)
        if not fl:
            self.label_2.setText('No Tasks For Today')

    def calendar_b(self):
        # реакция на нажатие кнопки меню
        if not self.calendar.isChecked():
            self.calendar.setChecked(True)
        if self.tasks.isChecked():
            self.tasks.setChecked(False)
        if self.schedule.isChecked():
            self.schedule.setChecked(False)
        if self.settings.isChecked():
            self.settings.setChecked(False)
        self.stackedWidget.setCurrentIndex(1)
        date = self.calendarWidget.selectedDate().toString('yyyy-MM-dd')
        self.dateselected.setText(date)
        for i in self.cur.execute('''SELECT title from acttasks WHERE date = ?''', (date,)).fetchall():
            a = MyCheckBox(i[0], self)
            a.setFont(QFont('MS Shell Dlg 2', 10))
            a.setStyleSheet("MyCheckBox::indicator"
                            "{"
                            "width :15px;"
                            "height :15px;"
                            "}")
            self.verticalLayoutcalendar.insertWidget(0, a)

    def schedule_b(self):
        # реакция на нажатие кнопки меню
        if not self.schedule.isChecked():
            self.schedule.setChecked(True)
        if self.calendar.isChecked():
            self.calendar.setChecked(False)
        if self.tasks.isChecked():
            self.tasks.setChecked(False)
        if self.settings.isChecked():
            self.settings.setChecked(False)
        self.stackedWidget.setCurrentIndex(2)

    def settings_b(self):
        # реакция на нажатие кнопки меню
        if not self.settings.isChecked():
            self.settings.setChecked(True)
        if self.calendar.isChecked():
            self.calendar.setChecked(False)
        if self.schedule.isChecked():
            self.schedule.setChecked(False)
        if self.tasks.isChecked():
            self.tasks.setChecked(False)
        self.stackedWidget.setCurrentIndex(3)

    def today_b(self):
        # реакция на нажатие кнопки меню в разделе tasks
        if not self.today.isChecked():
            self.today.setChecked(True)
        if self.lists.isChecked():
            self.lists.setChecked(False)
        if self.completed.isChecked():
            self.completed.setChecked(False)
        if self.deleted.isChecked():
            self.deleted.setChecked(False)
        self.stackedWidget_2.setCurrentIndex(0)
        self.clearLayout(self.verticalLayoutpage1)
        fl = 0
        for i in self.cur.execute('''SELECT title from acttasks WHERE date = ?''', (
                datetime.date.today(),)).fetchall():
            fl = 1
            a = MyCheckBox(i[0], self)
            a.selecteds.connect(self.edittask)
            a.setFont(QFont('MS Shell Dlg 2', 10))
            a.setStyleSheet("MyCheckBox::indicator"
                            "{"
                            "width :15px;"
                            "height :15px;"
                            "}")
            self.verticalLayoutpage1.insertWidget(0, a)
        if not fl:
            self.label_2.setText('No Tasks For Today')

    def lists_b(self):
        # реакция на нажатие кнопки меню в разделе tasks
        if not self.lists.isChecked():
            self.lists.setChecked(True)
        if self.today.isChecked():
            self.today.setChecked(False)
        if self.completed.isChecked():
            self.completed.setChecked(False)
        if self.deleted.isChecked():
            self.deleted.setChecked(False)
        lists = self.cur.execute('''SELECT title from lists''').fetchall()
        self.listsbox.addItems([i[0] for i in lists])
        self.stackedWidget_2.setCurrentIndex(1)

    def completed_b(self):
        # реакция на нажатие кнопки меню в разделе tasks
        if not self.completed.isChecked():
            self.completed.setChecked(True)
        if self.lists.isChecked():
            self.lists.setChecked(False)
        if self.today.isChecked():
            self.today.setChecked(False)
        if self.deleted.isChecked():
            self.deleted.setChecked(False)
        self.stackedWidget_2.setCurrentIndex(2)
        self.clearLayout(self.verticalLayoutpage3)
        fl = 0
        for i in self.cur.execute('''SELECT title from compltasks''').fetchall():
            fl = 1
            a = QLabel(i[0], self)
            a.setStyleSheet("font-size: 10pt")
            self.verticalLayoutpage3.insertWidget(0, a)
        if not fl:
            self.label_14.setText('No Tasks in Completed')

    def deleted_b(self):
        # реакция на нажатие кнопки меню в разделе tasks
        if not self.deleted.isChecked():
            self.deleted.setChecked(True)
        if self.lists.isChecked():
            self.lists.setChecked(False)
        if self.completed.isChecked():
            self.completed.setChecked(False)
        if self.today.isChecked():
            self.today.setChecked(False)
        self.stackedWidget_2.setCurrentIndex(3)
        self.clearLayout(self.verticalLayoutpage4)
        fl = 0
        for i in self.cur.execute('''SELECT title from deltasks''').fetchall():
            fl = 1
            a = QLabel(i[0], self)
            a.setStyleSheet("font-size: 10pt")
            self.verticalLayoutpage4.insertWidget(0, a)
        if not fl:
            self.label_16.setText('No Tasks in Deleted')

    def addtask_b(self):
        # функция добавления задачи
        title, ok_pressed = QInputDialog.getText(self, "New today task",
                                                 "Enter title:")
        if ok_pressed:
            self.label_2.setText('')
            a = MyCheckBox(title, self)
            a.selecteds.connect(self.edittask)
            a.setFont(QFont('MS Shell Dlg 2', 10))
            a.setStyleSheet("MyCheckBox::indicator"
                            "{"
                            "width :15px;"
                            "height :15px;"
                            "}")
            self.verticalLayoutpage1.insertWidget(0, a)
            self.cur.execute('''INSERT INTO acttasks(title, date) VALUES(?, ?)''', (
                title, datetime.date.today()))
            self.connect.commit()

    def tablef(self, r, c):
        # функция отображения инф. об уроке при нажатии на элемент таблицы
        if not self.tableWidget.item(r, c).text() == ' ':
            inf = self.cur.execute('''SELECT teacher, klass from subjects WHERE
             subject = ?''', (self.tableWidget.item(r, c).text(),)).fetchall()
            if self.tableWidget.item(r, c).text() in ['Алг./Геом.', 'Английский язык',
                                                      'Информатика', 'Спецкурс', 'Доп.матем.']:
                inf2 = self.cur.execute('''SELECT groupp FROM groups WHERE subj = ?''', (
                    self.tableWidget.item(r, c).text(),)).fetchone()
                if inf2[0] == 'None':
                    self.teacher.setText('Choose group in settings')
                    self.klass.setText('Choose group in settings')
                else:
                    f = inf[0][0].split(', ').index(inf2[0])
                    self.teacher.setText(inf[0][0].split(', ')[f])
                    self.klass.setText(inf[0][1].split(', ')[c].split('.')[f])
            else:
                self.teacher.setText(inf[0][0])
                self.klass.setText(inf[0][1].split(', ')[c])
            self.time.setText(self.sh[r])

    def groupm(self, text):
        # сохранение изменения группы по математике
        self.cur.execute('''UPDATE groups SET groupp = ?
         WHERE subj == "Алг./Геом." or subj == "Доп.матем."''', (text,))
        self.connect.commit()

    def groupe(self, text):
        # сохранение изменения группы по английскому
        self.cur.execute('''UPDATE groups SET groupp = ?
         WHERE subj = "Английский язык"''', (text,))
        self.connect.commit()

    def groupi(self, text):
        # сохранение изменения группы по информатике
        self.cur.execute('''UPDATE groups SET groupp = ?
         WHERE subj = "Информатика"''', (text,))
        self.connect.commit()

    def groupc(self, text):
        # сохранение изменения группы спецкурса
        self.cur.execute('''UPDATE groups SET groupp = ?
         WHERE subj = "Спецкурс"''', (text,))
        self.connect.commit()

    def calendartasks(self, date):
        # отображение задач конкретной даты календаря
        self.clearLayout(self.verticalLayoutcalendar)
        date = date.toString('dd.MM.yyyy')
        self.dateselected.setText(date)
        for i in self.cur.execute('''SELECT title from acttasks 
        WHERE date = ?''', (date,)).fetchall():
            a = MyCheckBox(i[0], self)
            a.setFont(QFont('MS Shell Dlg 2', 10))
            a.setStyleSheet("MyCheckBox::indicator"
                            "{"
                            "width :15px;"
                            "height :15px;"
                            "}")
            self.verticalLayoutcalendar.insertWidget(0, a)

    def savetoc(self, layout, date=None, list=None):
        # функция сохранения выполненных задач
        for i in range(layout.count() - 1):
            child = layout.itemAt(i)
            if child:
                if child.widget().isChecked():
                    self.cur.execute('''INSERT INTO compltasks(title, date, list) 
                    VALUES(?, ?, ?)''', (child.widget().text(), date, list))
                    self.cur.execute('''DELETE from acttasks WHERE 
                                    title = ? and date = ?''', (
                        child.widget().text(), date))
                    child.widget().close()
                    self.connect.commit()

    def edittask(self):
        # функция изменения задачи
        self.whatediting = self.sender()
        self.saveb.setEnabled(True)
        self.delete_2.setEnabled(True)
        self.textEdit.setReadOnly(False)
        self.textEdit_2.setReadOnly(False)
        self.textEdit.setPlainText(self.sender().text())
        self.textEdit_2.setPlainText('Description')
        d = self.cur.execute('''SELECT date from acttasks 
        WHERE title = ?''', (self.sender().text(),)).fetchall()
        lis = self.cur.execute('''SELECT lists.title from acttasks, lists 
                WHERE acttasks.title = ? and acttasks.idlist = lists.id''', (
            self.sender().text(),)).fetchall()
        if d[0][0]:
            self.dateEdit.setDate(datetime.datetime.strptime(d[0][0], '%Y-%m-%d'))
        else:
            self.dateEdit.setDate(datetime.date(1, 1, 1))
        if lis:
            self.comboBox_2.setCurrentText(lis[0][0])

    def listselection(self):
        # реакция на изменение списка задач
        if self.sender().currentText() == 'New List':
            # добавление нового списка
            title, ok_pressed = QInputDialog.getText(self, "New List",
                                                     "Enter title:")
            if ok_pressed:
                self.label_13.setText('')
                self.listsbox.addItem(title)
                self.listsbox.setCurrentText(title)
                self.cur.execute('''INSERT INTO lists(title) VALUES(?)''', (title,))
                self.connect.commit()
        elif self.sender().currentText() != 'Lists':
            # отображение задач выбранного списка
            self.clearLayout(self.verticalLayoutpage2)
            self.addtasktl.setEnabled(True)
            fl = 0
            self.label_13.setText('')
            for i in self.cur.execute('''SELECT acttasks.title from acttasks, lists 
            WHERE acttasks.idlist = lists.id and lists.title = ?''', (
                    self.listsbox.currentText(),)).fetchall():
                fl = 1
                a = MyCheckBox(i[0], self)
                a.selecteds.connect(self.edittask)
                a.setFont(QFont('MS Shell Dlg 2', 10))
                a.setStyleSheet("MyCheckBox::indicator"
                                "{"
                                "width :15px;"
                                "height :15px;"
                                "}")
                self.verticalLayoutpage2.insertWidget(0, a)
            if not fl:
                self.label_13.setText('No Tasks in ' + self.listsbox.currentText())

    def addtasktl_b(self):
        # добавление задачи в выбранный список
        title, ok_pressed = QInputDialog.getText(self, f"New {self.listsbox.currentText()} task",
                                                 "Enter title:")
        if ok_pressed:
            self.label_13.setText('')
            a = MyCheckBox(title, self)
            a.selecteds.connect(self.edittask)
            a.setFont(QFont('MS Shell Dlg 2', 10))
            a.setStyleSheet("MyCheckBox::indicator"
                            "{"
                            "width :15px;"
                            "height :15px;"
                            "}")
            self.verticalLayoutpage2.insertWidget(0, a)
            listid = self.cur.execute('''SELECT lists.id from lists 
            WHERE lists.title = ?''', (self.listsbox.currentText(),)).fetchall()
            self.cur.execute('''INSERT INTO acttasks(title, idlist) VALUES(?, ?)''', (
                title, listid[0][0]))
            self.connect.commit()

    def saving(self):
        # сохранение изменений задачи
        a = self.cur.execute('''SELECT id from lists WHERE title = ?''', (
            self.comboBox_2.currentText(),)).fetchall()
        self.cur.execute('''UPDATE acttasks SET title = ?, 
        description = ?, 
        idlist = ?, 
        date = ? 
        WHERE 
        title = ?''', (
            self.textEdit.toPlainText(),
            self.textEdit_2.toPlainText(),
            a[0][0] if a else None,
            self.dateEdit.date().toString('yyyy-MM-dd'),
            self.whatediting.text(),

        ))
        self.whatediting.setText(self.textEdit.toPlainText())
        self.connect.commit()

    def delb(self):
        # удаление задачи
        list = self.cur.execute('''SELECT lists.title from lists, acttasks a WHERE
         a.idlist = lists.id and a.title = ?''', (
            self.whatediting.text(),)).fetchall()
        date = self.cur.execute('''SELECT date from acttasks WHERE 
                 title = ?''', (
            self.whatediting.text(),)).fetchall()
        self.cur.execute('''INSERT INTO deltasks(title, date, list) 
        VALUES(?, ?, ?)''', (
            self.whatediting.text(), date[0][0] if date else None, list[0][0] if list else None))
        self.cur.execute('''DELETE from acttasks WHERE 
                        title = ? and date = ?''', (
            self.whatediting.text(), date[0][0] if date else None))
        self.whatediting.close()
        self.connect.commit()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MyWidget()
    ex.show()
    sys.exit(app.exec_())
    self.connect.close()
